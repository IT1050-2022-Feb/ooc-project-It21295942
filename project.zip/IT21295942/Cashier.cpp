#include<iostream>
using namespace std;
#include <string>
#include"Cashier.h"

Cashier::Cashier()

{
cout << "Default Constructor Cashier() called" << endl;
}

Cashier::Cashier(int pCashierID,string pPassword)

{
  CashierID=pCashierID;
  Password=pPassword; 
}

Cashier::~Cashier()

{
 cout << "Destructed" << endl;
}
