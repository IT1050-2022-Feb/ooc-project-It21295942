#define SIZE[10]
#include"Payment.h"
#include"User.h"

class Cashier : public User{

private:

int CashierID;
string Password;
Payment* Payments[SIZE];

public:

Cashier();
Cashier(int pCashierID,string pPassword);
Void addPayment(Payment *1);
void GenerateReport();
void ManageOrders();
void ManageDelivery();

~Cashier();
};
