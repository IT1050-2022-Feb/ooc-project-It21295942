#include<iostream>
using namespace std;
#include <string>
#include"Payment.h"
Payment::Payment()
  {
cout << "Default Constructor Payment() called" << endl;
}
Payment::Payment(int pPaymentID, string pPaymentType,double pPaymentAmount,string pDate){
PaymentID=pPaymentID;
PaymentType=pPaymentType;
PaymentAmount=pPaymentAmount;
Date=pDate;
}
Payment::~Payment()
{
 cout << "Destructed" << endl;
}
