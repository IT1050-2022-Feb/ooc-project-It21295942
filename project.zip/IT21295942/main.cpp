#include <iostream>
using namespace std;


#include "User.cpp"
#include "Feedback.cpp"
#include "Payment.cpp"
#include "Cashier.cpp"
#include "RegisteredUser.cpp"
#include "Delivery.cpp"
#include "UnregisteredUser.cpp"
#include  "Admin.cpp"
#include "order.cpp"
#include  "Item.cpp"




int main() {


  
Casheir *C1=new Casheir("123","Bigbang");
Casheir *C2=new Casheir("124","Bigbang2");
  
Payment *P1=new Payment("001","COD",2000.00,"2001-02-03",C1);
Payment *P2=new Payment("002","Online",1000.00,"2001-04-03",C2);
  
Feedback *F1= new Feedback(1,"good");
Feedback *F2= new Feedback(2,"bad");


RegisteredUser *R1=(1,"panzer","jude");
RegisteredUser *R2=(2,"panze445r","june");

Delivery *D1=(1,"Kurunegala","8.00 PM");
Delivery *D2=(2,"Malabe","7.30 AM"); 


User *U1=("Rogar","Rogar@gmail.com");
User *U2=("umarr","Umarr@gmail.com");
  
UnregisteredUser *UU1=("Kurunegala","01123552");
UnregisteredUser *UU2=("Malabe","09952112");
  
Admin *A1=(1125,"Toolsh56");
Admin *A2=(12336,"Tuupllsh56");

Item *I1=(1,"Bag",4,200.00);
Item *I2=(2,"Shoes",4,900.00);

Order *O1=(2,"2022-2-9",2000.00);
Order *O2=(5,"2022-2-9",8000.00);


  return 0;
}