#include<iostream>
using namespace std;
#include <string>
#include"Feeback.h"

Feedback::Feedback()
{
cout << "Default Constructor Admin() called" << endl;
}

Feedback::Feedback(int pFeedbackID,string pFeedbackDetails){
  FeedbackID=pFeedbackID;
  FeedbackDetails=pFeedbackDetails;
}
Feedback::~Feedback()
{
 cout << "Destructed" << endl;
}
