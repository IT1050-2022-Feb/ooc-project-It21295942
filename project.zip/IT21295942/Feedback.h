#include <string>
class Feedback{

private:

int FeedbackID;
string FeedbackDetails;

public:

Feedback();
Feedback(int pFeedbackID,string pFeedbackDetails);
void GenerateReport();
void DisplayDetails();
void StoreDetails();

~Feedback();

};
