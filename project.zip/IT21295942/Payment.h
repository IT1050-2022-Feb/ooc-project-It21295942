#define SIZE 10
#include <string>
#include"Cashier.h"
class Payment{

private:
Cashier* Cashiers;
int PaymentID;
string PaymentType;
double PaymentAmount;C
string Date;
public:
Payment();
Payment(int pPaymentID, string pPaymentType,double pPaymentAmount,string pDate, Cashier* pCashiers);
void CalcPayment();
void DisplayDetails();
~Payment();
};
